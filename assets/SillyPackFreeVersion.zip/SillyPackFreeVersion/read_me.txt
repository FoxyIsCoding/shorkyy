THANK YOU SO MUCH FOR DOWNLOADING THE PACK!  
Silly Pack was made by Thanatos_Pixelart!  
You can find me on Instagram, X, and TikTok!

This is just the beginning of a journey — I plan to keep updating this pack a lot over the next few years.  
So if you have ideas or feedback, feel free to reach out!

_______________________________________________________________________________

>>> Content - Free Pack

 - Grasslands tileset  
 - Animated tiles  
 - Animations for Player, Chicken, Pig, and Goblin
 - Grasslands background

_______________________________________________________________________________

>>> License - Free Pack

 - ✅ You **CAN** modify the assets!  
   [Use them as a reference, create your own sprites — be creative!]

 - ❌ You **CANNOT** use this asset pack in commercial projects.

 - ❌ You **CANNOT** redistribute or resell this asset pack on any platform  
   (even if modified).  
   [Of course, you can share the projects *made with* this asset pack — like games, software, etc.]

 - ⚠️ Credit is **required**!  
   [Example: "Assets from: Silly Pack — by Thanatos_Pixelart"]

_______________________________________________________________________________

That’s all! Have fun with your projects, and thanks for reading! 💖

- Thanatos_Pixelart

📸 Instagram: https://www.instagram.com/thanatos_pixelart/  
🐦 X (Twitter): https://x.com/thanatospxl  
🎵 TikTok: https://www.tiktok.com/@thanatospxl
